import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:testing/state_management/events/capture_event.dart';
import 'package:testing/state_management/events/ocr_event.dart';
import 'package:testing/state_management/events/text_to_speech_event.dart';
import 'package:testing/state_management/states/capture_state.dart';
import 'package:testing/state_management/states/ocr_state.dart';
import '../state_management/bloc/capture_bloc.dart';
import '../state_management/bloc/ocr_bloc.dart';
import '../state_management/bloc/text_to_speech_bloc.dart';
import '../services/camera_service.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OCR Capture')),
      body: BlocProvider(
        create: (context) => CaptureBloc(cameraService: CameraService()),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                BlocProvider.of<CaptureBloc>(context)
                    .add(const CaptureThroughSpeak());
              },
              child: const Text('Capture Image through Speech'),
            ),
            BlocBuilder<CaptureBloc, CaptureState>(
              builder: (context, state) {
                // Check if the state is CaptureImageSuccess and if the image is available
                if (state is CaptureImageSuccess) {
                  return Image.file(
                      File(state.image.path)); // Access the image property
                } else {
                  return const Text('No image captured');
                }
              },
            ),
            ElevatedButton(
              onPressed: () {
                // Check if the current state is CaptureImageSuccess
                if (BlocProvider.of<CaptureBloc>(context).state
                    is CaptureImageSuccess) {
                  final imageFile = (BlocProvider.of<CaptureBloc>(context).state
                          as CaptureImageSuccess)
                      .image;
                  BlocProvider.of<OcrBloc>(context)
                      .add(OcrExtractText(imagePath: imageFile));
                }
              },
              child: const Text('Extract Text'),
            ),
            BlocBuilder<OcrBloc, OcrState>(
              builder: (context, state) {
                if (state is OcrExtractFailure) {
                  return Text('Error: ${state.error}');
                }
                if (state is OcrExtractSuccess) {
                  if (state.result.text.isEmpty) {
                    return const Text('No text detected');
                  }
                  return Text(state.result.text);
                }
                return const Text('Processing...');
              },
            ),
            ElevatedButton(
              onPressed: () {
                final ocrState = BlocProvider.of<OcrBloc>(context).state;

                // Check if the current state is OcrExtractSuccess
                if (ocrState is OcrExtractSuccess) {
                  final detectedText = ocrState.result.text;

                  // If there's text, pass it to the TtsBloc
                  if (detectedText.isNotEmpty) {
                    BlocProvider.of<TtsBloc>(context)
                        .add(TtsSpeak(text: detectedText));
                  }
                } else {
                  // Handle the case where OCR hasn't been successful
                  print("No text to read.");
                }
              },
              child: const Text('Read Text Aloud'),
            ),
          ],
        ),
      ),
    );
  }
}
