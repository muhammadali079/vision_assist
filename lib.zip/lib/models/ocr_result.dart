class OcrResult {
  final String text;

  OcrResult({required this.text});
}
