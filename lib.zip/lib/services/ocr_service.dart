import 'package:camera/camera.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class OcrService {
  // Create an instance of the text recognizer
  final TextRecognizer _textRecognizer = TextRecognizer();

  /// Method to extract text from an image
  Future<String> extractTextFromImage(XFile image) async {
    try {
      // Convert the image to InputImage format
      final inputImage = InputImage.fromFilePath(image.path);
      
      // Process the image for text recognition
      final recognizedText = await _textRecognizer.processImage(inputImage);

      // Return the recognized text
      return recognizedText.text;
    } catch (e) {
      print("Error in OCR process: $e");
      return "Error in recognizing text.";
    }
  }

  /// Method to close the text recognizer instance when no longer needed
  Future<void> close() async {
    await _textRecognizer.close();
  }
}
