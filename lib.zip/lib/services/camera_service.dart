import 'package:camera/camera.dart';

class CameraService {
  late CameraController _cameraController;

  Future<void> initializeCamera() async {
    final cameras = await availableCameras();
    final firstCamera = cameras.first;
    _cameraController = CameraController(firstCamera, ResolutionPreset.high);
    await _cameraController.initialize();
  }

  Future<XFile?> captureImage() async {
    return await _cameraController.takePicture();
  }

  CameraController get controller => _cameraController;
}
