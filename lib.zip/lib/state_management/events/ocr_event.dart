import 'package:camera/camera.dart';
import 'package:equatable/equatable.dart';

abstract class OcrEvent extends Equatable {
  const OcrEvent();

  @override
  List<Object?> get props => [];
}

class OcrExtractText extends OcrEvent {
  final XFile imagePath; 

  const OcrExtractText({required this.imagePath});

  @override
  List<Object?> get props => [imagePath];
}
