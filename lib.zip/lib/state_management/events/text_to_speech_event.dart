import 'package:equatable/equatable.dart';

abstract class TtsEvent extends Equatable {
  const TtsEvent();

  @override
  List<Object?> get props => [];
}

class TtsSpeak extends TtsEvent {
  final String text;

  const TtsSpeak({required this.text});

  @override
  List<Object?> get props => [text];
}
