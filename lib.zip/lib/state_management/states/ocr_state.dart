import 'package:equatable/equatable.dart';
import 'package:testing/models/ocr_result.dart';

abstract class OcrState extends Equatable {
  const OcrState();

  @override
  List<Object?> get props => [];
}

class OcrInitial extends OcrState {}

class OcrExtractSuccess extends OcrState {
  final OcrResult result;

  const OcrExtractSuccess({required this.result});

  @override
  List<Object?> get props => [result];
}

class OcrExtractFailure extends OcrState {
  final String error;

  const OcrExtractFailure({required this.error});

  @override
  List<Object?> get props => [error];
}
