import 'package:equatable/equatable.dart';

abstract class TtsState extends Equatable {
  const TtsState();

  @override
  List<Object?> get props => [];
}

class TtsInitial extends TtsState {}

class TtsSpeakSuccess extends TtsState {}

class TtsSpeakFailure extends TtsState {
  final String error;

  const TtsSpeakFailure({required this.error});

  @override
  List<Object?> get props => [error];
}
