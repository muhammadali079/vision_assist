import 'package:camera/camera.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:testing/state_management/events/capture_event.dart';
import 'package:testing/state_management/states/capture_state.dart';
import '../../services/camera_service.dart';

class CaptureBloc extends Bloc<CaptureEvent, CaptureState> {
  final CameraService cameraService;

  CaptureBloc({required this.cameraService}) : super(CaptureInitial()) {
    on<CaptureThroughSpeak>(_onCaptureThroughSpeak);
  }

  void _onCaptureThroughSpeak(CaptureThroughSpeak event, Emitter<CaptureState> emit) async {
    try {
      // Capture the image
      final XFile? capturedImage = await cameraService.captureImage();
      if (capturedImage != null) {
        emit(CaptureImageSuccess(image: capturedImage));
      }
    } catch (e) {
      // Handle error (optional)
      emit(CaptureClose()); // In case of failure
    }
  }
}
