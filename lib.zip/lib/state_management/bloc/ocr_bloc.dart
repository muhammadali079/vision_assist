import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:testing/models/ocr_result.dart';
import 'package:testing/state_management/events/ocr_event.dart';
import 'package:testing/state_management/states/ocr_state.dart';
import '../../services/ocr_service.dart';

class OcrBloc extends Bloc<OcrEvent, OcrState> {
  final OcrService ocrService;

  OcrBloc({required this.ocrService}) : super(OcrInitial()) {
    on<OcrExtractText>(_onOcrExtractText);
  }

  void _onOcrExtractText(OcrExtractText event, Emitter<OcrState> emit) async {
    try {
      // Extract text using OCR service
      final text = await ocrService.extractTextFromImage(event.imagePath);
      if (text.isNotEmpty) {
        emit(OcrExtractSuccess(result: OcrResult(text: text)));
      } else {
        emit(const OcrExtractFailure(error: "No text found"));
      }
    } catch (e) {
      // Handle errors
      emit(OcrExtractFailure(error: e.toString()));
    }
  }
}
