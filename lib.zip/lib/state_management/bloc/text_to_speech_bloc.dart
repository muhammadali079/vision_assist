import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:testing/services/tts_service.dart';
import 'package:testing/state_management/events/text_to_speech_event.dart';
import 'package:testing/state_management/states/text_to_speech_state.dart';

class TtsBloc extends Bloc<TtsEvent, TtsState> {
  final TtsService ttsService;

  TtsBloc({required this.ttsService}) : super(TtsInitial()) {
    on<TtsSpeak>(_onTtsSpeak);
  }

  void _onTtsSpeak(TtsSpeak event, Emitter<TtsState> emit) async {
    try {
      // Call the TTS service to speak the text
      await ttsService.speak(event.text);
      emit(TtsSpeakSuccess());
    } catch (e) {
      emit(TtsSpeakFailure(error: e.toString()));
    }
  }
}
